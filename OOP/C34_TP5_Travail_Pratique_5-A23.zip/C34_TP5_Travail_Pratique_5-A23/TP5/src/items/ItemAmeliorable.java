package items;

public interface ItemAmeliorable {
    public void ameliorer();



}
