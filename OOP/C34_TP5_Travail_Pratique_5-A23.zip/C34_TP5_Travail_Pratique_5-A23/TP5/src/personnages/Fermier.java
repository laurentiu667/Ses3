package personnages;

public class Fermier extends PersonnageObservateur{
    public Fermier(String nom) {
        super(nom, 0);
    }

    @Override
    public void saluer() {
        super.saluer();
    }
}

